schema: '1.2'
contents:
  - components/model_version.fga
  - components/user.fga
  - components/role.fga
  - components/server.fga
  - components/project.fga
  - components/warehouse.fga
  - components/namespace.fga
  - components/lakekeeper_table.fga
  - components/lakekeeper_view.fga
  - components/lakekeeper_generic_table.fga
  - components/lakekeeper_catalog_tag.fga
