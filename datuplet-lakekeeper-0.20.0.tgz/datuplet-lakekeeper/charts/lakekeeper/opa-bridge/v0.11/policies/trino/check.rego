# Contains convenience wrappers around Lakekeeper functions and rules
# to reduce the number inputs required to call them
package trino

import data.configuration
import data.lakekeeper

catalog_config_by_name[catalog_name] := trino_catalog if {
	some trino_catalog in configuration.trino_catalog
	catalog_name := trino_catalog.name
}

# flatten properties by merging extra_properties into the main properties object
flatten_properties(properties) := flattened if {
	extra := object.get(properties, "extra_properties", {})
	base := object.remove(properties, ["extra_properties"])
	flattened := object.union(base, extra)
}

# Iceberg REST Namespaces are multi part identifiers (arrays).
# Trino schemas are strings separated by dots.
namespace_for_schema(schema_name) := namespace_name if {
	namespace_name := split(schema_name, ".")
	count(namespace_name) > 0
}

is_nested_schema(schema_name) := is_nested if {
	namespace_name := namespace_for_schema(schema_name)
	is_nested := count(namespace_name) > 1
}

parent_schema(schema_name) := parent_schema if {
	namespace_name := namespace_for_schema(schema_name)
	parent_namespace := array.slice(namespace_name, 0, count(namespace_name) - 1)
	parent_schema := concat(".", parent_namespace)
}

require_catalog_access_simple(catalog_name, action) if {
	trino_catalog := catalog_config_by_name[catalog_name]
	lakekeeper.require_warehouse_access_simple(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		lakekeeper_user_id,
		action,
	)
}

require_catalog_create_namespace_access(catalog_name, properties, name) if {
	trino_catalog := catalog_config_by_name[catalog_name]
	lakekeeper.require_warehouse_create_namespace_access(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		lakekeeper_user_id,
		properties,
		name,
	)
}

require_schema_access_simple(catalog_name, schema_name, action) if {
	trino_catalog := catalog_config_by_name[catalog_name]
	namespace_name := namespace_for_schema(schema_name)
	lakekeeper.require_namespace_access_simple(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		namespace_name,
		lakekeeper_user_id,
		action,
	)
}

require_schema_access_create(catalog_name, schema_name, action, properties, name) if {
	trino_catalog := catalog_config_by_name[catalog_name]
	namespace_name := namespace_for_schema(schema_name)
	lakekeeper.require_namespace_access_create(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		namespace_name,
		lakekeeper_user_id,
		action,
		properties,
		name,
	)
}

# Not used yet
require_schema_access_update_properties(catalog_name, schema_name, removed_properties, updated_properties) if {
	trino_catalog := catalog_config_by_name[catalog_name]
	namespace_name := namespace_for_schema(schema_name)
	lakekeeper.require_namespace_access_update_properties(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		namespace_name,
		lakekeeper_user_id,
		removed_properties,
		updated_properties,
	)
}

require_table_access_simple(catalog_name, schema_name, table_name, action) if {
	trino_catalog := catalog_config_by_name[catalog_name]
	namespace_name := namespace_for_schema(schema_name)
	lakekeeper.require_table_access_simple(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		namespace_name,
		table_name,
		lakekeeper_user_id,
		action,
	)
}

require_table_access_commit(catalog_name, schema_name, table_name, updated_properties, removed_properties) if {
	trino_catalog := catalog_config_by_name[catalog_name]
	namespace_name := namespace_for_schema(schema_name)
	lakekeeper.require_table_access_commit(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		namespace_name,
		table_name,
		lakekeeper_user_id,
		updated_properties,
		removed_properties,
	)
}

require_view_access_simple(catalog_name, schema_name, view_name, action) if {
	trino_catalog := catalog_config_by_name[catalog_name]
	namespace_name := namespace_for_schema(schema_name)
	lakekeeper.require_view_access_simple(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		namespace_name,
		view_name,
		lakekeeper_user_id,
		action,
	)
}

# A rename into another schema moves the table or view: it also needs `move` on
# the source and `accept_moved_tabular` on the target schema. `kind` is "table"
# or "view". A rename into another catalog is refused.
require_rename_target_access(_, source_catalog, source_schema, _, target_catalog, target_schema) if {
	source_catalog == target_catalog
	source_schema == target_schema
}

require_rename_target_access(kind, source_catalog, source_schema, name, target_catalog, target_schema) if {
	source_catalog == target_catalog
	source_schema != target_schema
	trino_catalog := catalog_config_by_name[source_catalog]
	lakekeeper.require_tabular_move_access(
		trino_catalog.lakekeeper_id,
		trino_catalog.lakekeeper_warehouse,
		kind,
		namespace_for_schema(source_schema),
		name,
		namespace_for_schema(target_schema),
		lakekeeper_user_id,
	)
}

child_schema_name(schema_name) := child_name if {
	parts := split(schema_name, ".")
	child_name := parts[count(parts) - 1]
}

is_metadata_table(table_name) if {
	table_name_suffixes := [
		"$properties", "$history", "$metadata_log_entries",
		"$snapshots", "$manifests", "$all_manifests",
		"$partitions", "$files", "$entries", "$all_entries", "$refs",
	]
	some suffix in table_name_suffixes
	endswith(table_name, suffix)
} else := false

split_metadata_table_name(table_name) := base_table_name if {
	table_name_suffixes := [
		"$properties", "$history", "$metadata_log_entries",
		"$snapshots", "$manifests", "$all_manifests",
		"$partitions", "$files", "$entries", "$all_entries", "$refs",
	]
	some suffix in table_name_suffixes
	endswith(table_name, suffix)
	base_table_name := substring(table_name, 0, count(table_name) - count(suffix))
}
