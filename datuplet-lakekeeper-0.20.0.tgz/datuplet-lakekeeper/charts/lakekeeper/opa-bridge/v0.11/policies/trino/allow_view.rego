package trino

allow_view if {
	allow_view_modify
}

allow_view if {
	allow_view_create
}

allow_view if {
	allow_view_rename
}

allow_view if {
	allow_view_drop
}

allow_view if {
	allow_view_metadata
}

allow_view if {
	allow_view_read
}

allow_view_create if {
	input.action.operation in ["CreateView", "CreateMaterializedView"]
	catalog := input.action.resource.table.catalogName
	schema := input.action.resource.table.schemaName
	view := input.action.resource.table.tableName
	properties := object.get(input.action.resource.table, "properties", {})
	flattened_properties := flatten_properties(properties)
	require_schema_access_create(catalog, schema, "create_view", flattened_properties, view)
}

allow_view_modify if {
	input.action.operation == "SetViewComment"
	catalog := input.action.resource.table.catalogName
	schema := input.action.resource.table.schemaName
	table := input.action.resource.table.tableName
	require_view_access_simple(catalog, schema, table, "write_data")
}

allow_view_rename if {
	input.action.operation == "RenameView"
	source_catalog := input.action.resource.table.catalogName
	source_schema := input.action.resource.table.schemaName
	source_table := input.action.resource.table.tableName
	require_view_access_simple(source_catalog, source_schema, source_table, "rename")
	target_catalog := input.action.targetResource.table.catalogName
	target_schema := input.action.targetResource.table.schemaName
	require_schema_access_simple(target_catalog, target_schema, "create_view")
	require_rename_target_access("view", source_catalog, source_schema, source_table, target_catalog, target_schema)
}

allow_view_drop if {
	input.action.operation == "DropView"
	catalog := input.action.resource.table.catalogName
	schema := input.action.resource.table.schemaName
	table := input.action.resource.table.tableName
	require_view_access_simple(catalog, schema, table, "drop")
}

allow_view_metadata if {
	input.action.operation in ["FilterTables", "ShowColumns", "FilterColumns"]
	catalog := input.action.resource.table.catalogName
	schema := input.action.resource.table.schemaName
	table := input.action.resource.table.tableName
	require_view_access_simple(catalog, schema, table, "get_metadata")
}

allow_view_read if {
	input.action.operation in ["SelectFromColumns", "CreateViewWithSelectFromColumns"]
	catalog := input.action.resource.table.catalogName
	schema := input.action.resource.table.schemaName
	table := input.action.resource.table.tableName
	require_view_access_simple(catalog, schema, table, "select")
}
